#include <string>
#include <vector>
#include <set>
#include <limits.h>

using namespace std;

enum trafficWeight {low, normal, heavy};

struct Road {
    string roadName;
    string v1;
    string v2;
    double w;
};

struct Day {
    vector<pair<string, trafficWeight>> road;
};

struct input {
    string source;
    string destination;
    vector<Road> roads;
    vector<Day> predictions;
    vector<Day> actualTraffic;
};

class AdjMatrixGraph {
    private:
        set<pair<string, double>>** adjMatrix; //where string corresponds to the road name and int corresponds to the weight.
        int numVertices;

    public:
    // Initialize the matrix to zero
    AdjMatrixGraph(int numVertices) {
        this->numVertices = numVertices;
        adjMatrix = new set<pair<string, double>>*[numVertices];
        for (int i = 0; i < numVertices; i++) {
            adjMatrix[i] = new set<pair<string, double>>[numVertices];
        }
    }

    // Add edges
    void addEdge(int i, int j, string roadName, double weight) {
        pair<string, double> info = make_pair(roadName, weight);
        adjMatrix[i][j].insert(info);
        adjMatrix[j][i].insert(info);
    }

    // Remove edges
    void removeEdge(int i, int j, string roadName, double weight) {
        pair<string, double> info = make_pair(roadName, weight);
        adjMatrix[i][j].erase(info);
        adjMatrix[j][i].erase(info);
    }

    // Print the number of roads to go from node[i] to node[j].
    void printGraph() {
        for (int i = 0; i < numVertices; i++) {
            cout << i << " : ";
            for (int j = 0; j < numVertices; j++)
                cout << adjMatrix[i][j].size() << " ";
            cout << "\n";
        }
    }

    int getSize(int i, int j) {
        return adjMatrix[i][j].size();
    }

    double getWeight(int i, int j) {
        double res = INT_MAX;
        for(auto x : adjMatrix[i][j]) {
            res = min(res, x.second);
        }
        return res;
    }

    void updateWeight(string roadname, int i, int j, trafficWeight traffic) { //ended up not using this
        double oldValue = -1;
        set<pair<string, double>>::iterator it;
        for(it = adjMatrix[i][j].begin(); it != adjMatrix[i][j].end(); it++) {
            if ((*it).first == roadname) {
                oldValue = (*it).second;
                break;
            }
        }

        removeEdge(i, j, roadname, oldValue);

        double newValue = oldValue;
        switch(traffic) {
            case low:
                newValue *= 0.9;
                break;
            case heavy:
                newValue *= 1.25;
                break;
            default:
                newValue *= 1;
                break;
        }

        addEdge(i, j, roadname, newValue);
    }

    ~AdjMatrixGraph() { //Deconstructor
        for (int i = 0; i < numVertices; i++)
            delete[] adjMatrix[i];
            delete[] adjMatrix;
    }
};

struct ucsResult {
    int visitedNodes;
    double runtime;
    double cost;
    vector<int> path;
};

struct idaStarResult {
    int visitedNodes;
    double runtime;
    double cost;
    vector<int> path;
};

struct lrtaStarResult {
    double cost;
    double runtime;
    vector<int> path;
};

/*
struct AdjListNode
{
    int dest;
    int w;
    string roadName;
    struct AdjListNode* next;
};
 
struct AdjList
{
    struct AdjListNode *head;
};


class AdjListGraph {
    private:
        int V;
        struct AdjList* array;

    public:
        AdjListGraph(int V)
        {
            this->V = V;
            array = new AdjList [V];
            for (int i = 0; i < V; ++i)
                array[i].head = NULL;
        }

        AdjListNode* newAdjListNode(int dest, string roadName, int w)
        {
            AdjListNode* newNode = new AdjListNode;
            newNode->dest = dest;
            newNode->roadName = roadName;
            newNode->w = w;
            newNode->next = NULL;
            return newNode;
        }

        void addEdge(int src, int dest, string roadName, int w)
        {
            AdjListNode* newNode = newAdjListNode(dest, roadName, w);
            newNode->next = array[src].head;
            array[src].head = newNode;
            newNode = newAdjListNode(src, roadName, w);
            newNode->next = array[dest].head;
            array[dest].head = newNode;
        }

        void printGraph()
        {
            int v;
            for (v = 0; v < V; ++v)
            {
                AdjListNode* pCrawl = array[v].head;
                cout<<"\n Adjacency list of vertex "<<v<<"\n head ";
                while (pCrawl)
                {
                    cout<<"-> ("<<pCrawl->dest<<", "<<pCrawl->roadName<<", "<<pCrawl->w<<")";
                    pCrawl = pCrawl->next;
                }
                cout<<endl;
            }
        }
}; */