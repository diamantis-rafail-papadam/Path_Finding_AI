#include <iostream>
#include <fstream>
#include <unordered_map>
#include <queue>
#include <iterator>
#include <unordered_set>
#include <chrono>
#include <stack>
#include <cmath>
#include <random>
#include "Reader.h"

#define graphType AdjMatrixGraph //either AdjMatrixGraph or AdjListGraph
#define Low 0.9
#define Normal 1
#define Heavy 1.25

void printReadInput(input &in) {
    cout << "Source: " << in.source << endl;
    cout << "Destination: " << in.destination << endl;
    cout << "Roads:" << endl;
    for(int i = 0; i < in.roads.size(); i++) {
        cout << in.roads[i].roadName << " " << in.roads[i].v1 << " " << in.roads[i].v2 << " " << in.roads[i].w << endl;
    }

    cout << "Predictions for traffic" << endl;
    for(int i = 0; i < in.predictions.size(); i++) {
        cout << "Day " << i+1 << endl;
        for(int j = 0; j < in.predictions[i].road.size(); j++) {
            cout << in.predictions[i].road[j].first << " " << in.predictions[i].road[j].second << endl;
        }
    }

    cout << "Real traffic" << endl;
    for(int i = 0; i < in.actualTraffic.size(); i++) {
      cout << "Day " << i+1 << endl;
      for(int j = 0; j < in.actualTraffic[i].road.size(); j++) {
           cout << in.actualTraffic[i].road[j].first << " " << in.actualTraffic[i].road[j].second << endl;
      }
    }
}

unordered_map<string, int> createRoadToIndex(vector<Road> &roads) {
    unordered_map<string, int> roadToIndex;

    for(int i = 0; i < roads.size(); i++) 
        roadToIndex.insert(pair<string, int> (roads[i].roadName, i));

    return roadToIndex;
}

unordered_map<string, int> createNodeToInt(vector<Road> &roads) {
    unordered_map<string, int> nodeToIndex;
    int counter = 0;

    for(int i = 0; i < roads.size(); i++) {
        string v1 = roads[i].v1;
        string v2 = roads[i].v2;

        try {
            int tmp = nodeToIndex.at(v1);
        } catch(out_of_range) {
            nodeToIndex.insert(pair<string, int> (v1, counter++));
        }

        try {
            int tmp = nodeToIndex.at(v2);
        } catch(out_of_range) {
            nodeToIndex.insert(pair<string, int> (v2, counter++));
        }

        assert(nodeToIndex.at(v1) != nodeToIndex.at(v2)); //if this assertion happens then the input is wrong.
    }

    return nodeToIndex;
}

unordered_map<int, string> createIntToNode(unordered_map<string, int> &nodeToInt) {
    unordered_map<int, string> intToNode;

    for (auto &it: nodeToInt) {
        intToNode.insert(pair<int, string> (it.second, it.first));
    }

    return intToNode;
}

void createGraph(graphType &graph, vector<Road> &roads, unordered_map<string, int> &nodeToInt) {
    for(int i = 0; i < roads.size(); i++) {
        int v1 = nodeToInt.at(roads[i].v1);
        int v2 = nodeToInt.at(roads[i].v2);

        graph.addEdge(v1, v2, roads[i].roadName, roads[i].w);
    }
}

bool roadIsDiscarded(string road, unordered_set<string> &discarded) {
    unordered_set<string>::iterator it = discarded.find(road);
    return it != discarded.end();
}

unordered_set<string> discardUnnecessaryRoads(vector<Road> &roads) { //if two roads connect the same nodes but 1.25*w1 <= 0.9*w2
    unordered_set<string> discardedRoads;
    for(int i = 0; i < roads.size() - 1; i++) { //then road that has weight of w2 will never be used.
        string v1 = roads[i].v1;
        string v2 = roads[i].v2;
        for(int j = i+1; j < roads.size(); j++) {
            if( (roads[j].v1 == v1 && roads[j].v2 == v2) || (roads[j].v1 == v2 && roads[j].v2 == v1) ) {
                if(Heavy * roads[i].w <= Low * roads[j].w) {
                    discardedRoads.insert(roads[j].roadName);
                    roads.erase(roads.begin() + j);
                } else if(Heavy * roads[j].w <= Low * roads[i].w) {
                    discardedRoads.insert(roads[i].roadName);
                    roads.erase(roads.begin() + i);
                }
            }
        }
    }                                            
    return discardedRoads;
}

void copyRoads(vector<Road> &roads, vector<Road> &dailyTraffic) {
    assert(dailyTraffic.size() == 0);
    for(int i = 0; i < roads.size(); i++)
        dailyTraffic.push_back((roads[i]));
}

bool roadInGraph(unordered_map<string, int> &nodeToIndex, string road) {
    bool flag = true;
    try {
        int tmp = nodeToIndex.at(road);
    } catch(out_of_range) {
        flag = false;
    }
    return flag;
}

void updateRoadTraffic(bool isPrediction, double p1, double p2, double p3, vector<Road> &dailyTraffic, int pos, trafficWeight prediction) {
    double newTraffic = dailyTraffic[pos].w;
    double dice = (double)(rand() % 100)/100;

    switch(prediction) {
        case low:
            if(isPrediction) {
                if (dice <= p1)
                    newTraffic *= Low;
                else if (dice <= p1 + p2)
                    newTraffic *= Normal;
                else
                    newTraffic *= Heavy;
            } else {
                newTraffic *= Low;
            }
            break;
        case heavy:
            if(isPrediction) {
                if (dice <= p1)
                    newTraffic *= Heavy;
                else if (dice <= p1 + p2)
                    newTraffic *= Normal;
                else
                    newTraffic *= Low;
            } else {
                newTraffic *= Heavy;
            }
            break;
        default: //case normal:
            if(isPrediction) {
                if (dice <= p1)
                    newTraffic *= Normal;
                else if (dice <= p1 + p2)
                    newTraffic *= Heavy;
                else
                    newTraffic *= Low;
            } else {
                newTraffic *= Normal;
            }
            break;
    }
    dailyTraffic[pos].w = newTraffic;
}

void updateRoads(bool flag, double p1, double p2, double p3, Day &day, vector<Road> &dailyTraffic, unordered_set<string> &discardedRoads, unordered_map<string, int> &roadToIndex) {
    for(int j = 0; j < day.road.size(); j++) {
        string r = day.road[j].first;
        if(roadIsDiscarded(r, discardedRoads))
            continue;
        trafficWeight prediction = day.road[j].second;
        int pos = roadToIndex[r];
        updateRoadTraffic(flag, p1, p2, p3, dailyTraffic, pos, prediction);
    }
}

pair<vector<int>, pair<double, int>> Dijkstra(graphType &graph, int size, int source, int dest) {
    vector<double> dist(size, INT_MAX);
    vector<int> prev(size, -1); 

    prev[source] = INT_MIN;
    dist[source] = 0;

    unordered_set<int> S;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> Q; //minimum heap keyed by dist.
    for(int i = 0; i < size; i++)
        Q.push(make_pair(dist[i], i));

    while(Q.empty() == false) {
        int node = Q.top().second;
        Q.pop();

        if(node == dest)
            break;
        
        S.insert(node);
        for(int i = 0; i < size; i++) {
            if(graph.getSize(node, i) != 0) {
                if(dist[node] + graph.getWeight(node, i) < dist[i]) { //relax operation
                    dist[i] = dist[node] + graph.getWeight(node, i);
                    Q.push(make_pair(dist[i], i)); //decrease key
                    prev[i] = node;
                }
            }
        }
    }

    return make_pair(prev, make_pair(dist[dest], S.size()));
}

ucsResult UCS(graphType &graph, int size, int source, int dest) {
    clock_t clc = clock();
    ucsResult ucsRes = {INT_MIN, INT_MIN, INT_MIN, {}};
    vector<double> dist(size, __DBL_MAX__);
    vector<int> prev(size, -1); //prev[node] == -1 means that the node is not reachable (yet).

    prev[source] = INT_MIN; //prev[source] = INT_MIN so that we can distinguish it in back tracking.
    dist[source] = 0;

    unordered_set<int> S;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> Q; //minimum heap keyed by dist.
    Q.push(make_pair(dist[source], source));

    int node;
    while(Q.empty() == false) {
        node = Q.top().second;
        Q.pop();
        S.insert(node);

        if(node == dest) //Source-target shortest path (we are not calculating the minimum distance from the source to all nodes).
            break;
        
        for(int i = 0; i < size; i++) { //find neighbours
            if(graph.getSize(node, i) != 0) { //if we can visit that node
                double d = dist[node] + graph.getWeight(node, i);
                if(d < dist[i]) { //relax operation
                    dist[i] = d;
                    Q.push(make_pair(dist[i], i)); //decrease key
                    prev[i] = node;
                }
            }
        }
    }

    ucsRes.visitedNodes = S.size();
    ucsRes.path = prev;
    ucsRes.cost = dist[dest];
    ucsRes.runtime = (double)(clock() - clc)/CLOCKS_PER_SEC;
    return ucsRes;
}

vector<double> createSimpleHeuristic(graphType &graph, int size, int dest) {
    vector<double> heuristic;
    double minPossibleDist = INT_MAX;
    for(int i = 0; i < size; i++)
        minPossibleDist = min(graph.getWeight(dest, i), minPossibleDist);
    assert(minPossibleDist != INT_MAX);
    for(int i = 0; i < size; i++) 
        heuristic.push_back(minPossibleDist * Low);
    heuristic[dest] = 0;
    return heuristic;
}

pair<idaStarResult, double> idaStarSearch(graphType &graph, vector<double> &h, int size, int source, int dest, double bound) {
    idaStarResult idaStarSearchRes = {INT_MIN, INT_MIN, INT_MIN, {}};
    vector<double> g(size, __DBL_MAX__);
    vector<double> f(size, __DBL_MAX__);
    vector<int> prev(size, -1); //prev[node] == -1 means that the node is not reachable (yet).

    prev[source] = INT_MIN; //prev[source] = INT_MIN so that we can distinguish it in back tracking.
    g[source] = 0;
    f[source] = h[source];

    unordered_set<int> S;
    priority_queue<pair<double, int>, vector<pair<double, int>>, greater<pair<double, int>>> Q; //minimum heap keyed by dist.   
    Q.push(make_pair(f[source], source));
    
    int node = -1;
    double res, minimum = __DBL_MAX__;
    while(Q.empty() == false) {
        node = Q.top().second;
        Q.pop();
        S.insert(node);

        if(node == dest)
            break;

        for(int i = 0; i < size; i++) {
            if(graph.getSize(node, i) != 0) { //if we can visit that node
                double dist = g[node] + graph.getWeight(node, i);
                if(dist < g[i]) {
                    prev[i] = node;
                    g[i] = dist;
                    f[i] = g[i] + h[i];
                    if(f[i] > bound) {
                        minimum = min(minimum, f[i]);
                    } else {
                        Q.push(make_pair(f[i], i));
                    }
                }
            }
        }
    }

    idaStarSearchRes.visitedNodes = S.size();
    if(node == dest) {
        idaStarSearchRes.path = prev;
        idaStarSearchRes.cost = f[dest];
        res = __DBL_MAX__; //means found.
    } else {
        res = minimum; //increasing the bound.
    }

    return make_pair(idaStarSearchRes, res);
}

idaStarResult idaStar(graphType &graph, vector<double> &h, int size, int source, int dest) {
    clock_t clc = clock();
    pair<idaStarResult, double> res;
    idaStarResult idaStarRes = {INT_MIN, INT_MIN, INT_MIN, {}};
    double searchRes;
    double bound = 0 + h[source]; //g[source] = 0.
    int totalNodesVisited = 0;
    
    while(true) {
        res = idaStarSearch(graph, h, size, source, dest, bound); //__DBL_MAX__ means found. Any other positive value returned will be the new bound.
        idaStarRes = res.first;
        searchRes = res.second;
        if(searchRes == __DBL_MAX__) //found.
            break;
        else {
            totalNodesVisited += idaStarRes.visitedNodes;
            bound = searchRes; //look deeper.
        }
    }
    
    idaStarRes.visitedNodes = totalNodesVisited + idaStarRes.visitedNodes;
    idaStarRes.runtime = (double)(clock() - clc)/CLOCKS_PER_SEC;
    return idaStarRes;
}

lrtaStarResult lrtaStar(graphType &graph, vector<double> &h, int size, int source, int dest) {
    clock_t clc = clock();
    lrtaStarResult lrtaStarRes = {INT_MIN, __DBL_MIN__};
    vector<int> prev(size, -1);
    vector<double> cost(size, __DBL_MAX__);

    prev[source] = INT_MIN;
    cost[source] = 0;

    int state = source, nextState;
    double neighborCost;
    while(state != dest) {
        double bestCost = __DBL_MAX__;
        for(int i = 0; i < size; i++) {
            if(graph.getSize(state, i) != 0) {
                neighborCost =  graph.getWeight(state, i) + h[i];
                if(neighborCost < bestCost) {
                    bestCost = neighborCost;
                    nextState = i;
                }
            }
        }

        h[state] = max(h[state], bestCost);

        prev[nextState] = state;
        cost[nextState] = cost[state] + graph.getWeight(state, nextState);

        state = nextState;
    }
    
    assert(state == dest);
    lrtaStarRes.cost = cost[dest];
    lrtaStarRes.path = prev;
    lrtaStarRes.runtime = (double)(clock() - clc)/CLOCKS_PER_SEC;
    return lrtaStarRes;
}

string keepNDecimals(string num, int n) {
    int pos = -1;
    for(int i = 0; i < num.size(); i++) {
        if(num[i] == '.') {
            pos = i;
            break;
        }
    }
    if (pos != -1)
        return num.substr(0, pos+n+1);
    else    
        return num;
}

string getPath(graphType &g, vector<int> &path, double predictedCost, string destination, unordered_map<string, int> &nodeToIndex, unordered_map<int, string> &indexToNode) {
    string stringPath = "";
    vector<double> weights;
    stack<string> s;
    double sumToMakeSure = 0;
    int counter = 0, prev = -1, curr = -1, index = nodeToIndex[destination];
    while(index != INT_MIN) {
        prev = curr;
        curr = index;
        if(prev != -1 && curr != -1) {
            double w = g.getWeight(curr, prev);
            weights.push_back(w);
            sumToMakeSure += w;
        }

        s.push(indexToNode[index]);
        index = path[index];
        assert(index != -1);
    }

    assert(sumToMakeSure > predictedCost - pow(10, 6) && sumToMakeSure < predictedCost + pow(10, 6)); //basically this is equality.

    while(s.empty() == false) {
        stringPath += s.top();
        s.pop();
        if(s.empty())
            continue;
        else
            stringPath += " --(" + keepNDecimals(to_string(weights[weights.size() - (++counter)]), 2) + ")--> ";
    }

    return stringPath + "\n";
}

string getDailyStats(graphType &g, int day, ucsResult ucsPredRes, ucsResult ucsActRes, idaStarResult idaStarPredRes, idaStarResult idaStarActRes, string dest, unordered_map<string, int> nodeToIndex, unordered_map<int, string> indexToNode) {
    string stats = "";
    //UCS
    stats += "Day " + to_string(day) + "\n" + "UCS:\n\tVisited Nodes number: " + to_string(ucsPredRes.visitedNodes) + "\n\tExecution Time: " + keepNDecimals(to_string(1000*ucsPredRes.runtime), 2) + "ms\n\tPath: ";
    stats += getPath(g, ucsPredRes.path, ucsPredRes.cost, dest, nodeToIndex, indexToNode);
    stats += "\tPredicted Cost: " + keepNDecimals(to_string(ucsPredRes.cost), 2) + "\n" + "\tReal cost: " + keepNDecimals(to_string(ucsActRes.cost), 2) + "\n";

    //IDA*
    stats += "IDA*:\n\tVisited Nodes number: " + to_string(idaStarPredRes.visitedNodes) +"\n\tExecution Time: " + keepNDecimals(to_string(1000*idaStarPredRes.runtime), 2) + "ms\n\tPath: ";
    stats += getPath(g, idaStarPredRes.path, idaStarPredRes.cost, dest, nodeToIndex, indexToNode);
    stats += "\tPredicted Cost: " + keepNDecimals(to_string(idaStarPredRes.cost), 2) + "\n" + "\tReal cost: " + keepNDecimals(to_string(idaStarActRes.cost), 2) + "\n";
    return stats;
}

double meanValue(vector<double> &arr) {
    double mean = 0;
    for(int i = 0; i < arr.size(); i++)
        mean += arr[i];
    return mean/arr.size();
}

void printExtraStatistics(vector<double> predictedCost, vector<double> actualCost, vector<double> lrtaStarCost, double discardTime, double ucsTime, double idaStarTime, double idaStarWithHeuristicTime, double lrtaStarTime, double p1, double p2, double p3, int numOfLtraTrials, double runtime) {
    printf("Additional Statistics:\n");
    //printf("Time taken to discard unnecessary roads: %.2fms\n", discardTime);
    printf("Average daily execution time of UCS: %.2fms\n", 1000*ucsTime/numOfDays);
    printf("Average daily execution time of IDA* disregarding heuristic creation: %.2fms\n", 1000*idaStarTime/numOfDays);
    printf("Average daily execution time of IDA* including heuristic creation: %.2fms\n", 1000*idaStarWithHeuristicTime/numOfDays);
    printf("Average daily execution time of LRTA* with %d trials: %.2fms\n\n", numOfLtraTrials, 1000*lrtaStarTime/numOfDays);
    printf("Average daily predicted cost for both UCS and IDA*: %.2f\n", meanValue(predictedCost));
    printf("Average daily real cost: %.2f\n", meanValue(actualCost));
    printf("Average daily LRTA* cost on real traffic after %d trials: %.2f\n\n", numOfLtraTrials, meanValue(lrtaStarCost));
    printf("Final values of our probabilities: p1 = %.2f, p2 = %.2f, p3 = %.2f\n", p1, p2, p3);
    printf("Execution time for the whole program: %.0fms\n\n", runtime);
    return;
}