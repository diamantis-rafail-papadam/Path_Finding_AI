#include <assert.h>     
#include <sstream>
#include "Classes-Structures.h"

using namespace std;
#define numOfDays 80

string getVertex(string &buf, string s, string e) {
    string res;
    int startIndex = buf.find(s) + s.length();
    int endIndex = buf.find(e);
    res = buf.substr(startIndex, endIndex-startIndex);
    buf.erase(0, endIndex + e.length());
    return res;
}

Road getRoad(string &road) {
    int pos;
    Road r;
    
    //read road name
    pos = road.find(";");
    r.roadName = road.substr(0, pos);
    road.erase(0, pos + 2);

    //read vertex 1
    pos = road.find(";");
    r.v1 = road.substr(0, pos);
    road.erase(0, pos + 2);

    //read vertex 2
    pos = road.find(";");
    r.v2 = road.substr(0, pos);
    road.erase(0, pos + 2);

    //read weight
    string stringWeight = road;
    r.w = stod(stringWeight);
    
    return r;
}

vector<Road> getRoads(string &buf) {
    vector<Road> roads;
    Road r;
    string road;
    string s = "<Roads>";
    string e = "</Roads>";
    int startIndex = buf.find(s) + s.length();
    int endIndex = buf.find(e);
    string stringRoads = buf.substr(startIndex, endIndex-startIndex);
    buf.erase(0, endIndex + e.length());
    stringstream ss(stringRoads);

    while(getline(ss, road, '\n')) {
        if(road == "") 
            continue;
        r = getRoad(road);
        roads.push_back(r);
    }

    return roads;
}

pair<string, trafficWeight> getDayRoad(string &dayRoad) {
    string roadName;
    trafficWeight traffic;
    
    //read road
    int pos = dayRoad.find(";");
    roadName = dayRoad.substr(0, pos);
    dayRoad.erase(0, pos + 2);
    
    //read traffic
    if(dayRoad == "low")
        traffic = low;
    else if(dayRoad == "normal")
        traffic = normal;
    else
        traffic = heavy;

    return make_pair(roadName, traffic);
}

Day getDay(string &day) {
    string dayRoad;
    pair<string, trafficWeight> dayR;
    vector<pair<string, trafficWeight>> dayVec;
    Day d;

    string s = "<Day>";
    string e = "</Day>";
    int startIndex = day.find(s) + s.length();
    int endIndex = day.find(e);
    string stringDay = day.substr(startIndex, endIndex-startIndex);
    day.erase(0, endIndex + e.length());
    stringstream ss(stringDay);

    while(getline(ss, dayRoad, '\n')) {
        if(dayRoad == "") 
            continue;
        dayR = getDayRoad(dayRoad);
        dayVec.push_back(dayR);
    }

    d.road = dayVec;
    return d;
}

vector<Day> getPredictions(string &buf) {
    vector<Day> p;

    string s = "<Predictions>";
    string e = "</Predictions>";
    int startIndex = buf.find(s) + s.length();
    int endIndex = buf.find(e);
    string stringPredictions = buf.substr(startIndex, endIndex-startIndex);
    buf.erase(0, endIndex + e.length());

    while(stringPredictions != "\n" && stringPredictions != "") { //this should run 80 times (the number of days)
        p.push_back(getDay(stringPredictions));
    }
    
    return p;
}

vector<Day> getActualTrafficPerDay(string &buf) {
    vector<Day> actTraf;

    string s = "<ActualTrafficPerDay>";
    string e = "</ActualTrafficPerDay>";
    int startIndex = buf.find(s) + s.length();
    int endIndex = buf.find(e);
    string stringActualTraffic = buf.substr(startIndex, endIndex-startIndex);
    buf.erase(0, endIndex + e.length());

    while(stringActualTraffic != "\n" && stringActualTraffic != "") { //this should run 80 times (the number of days)
        actTraf.push_back(getDay(stringActualTraffic));
    }

    return actTraf;
}

input readInput(string &buf) {
    string start, end;
    input in;

    //read source
    start = "<Source>";
    end = "</Source>";
    in.source = getVertex(buf, start, end);

    //read destination
    start = "<Destination>";
    end = "</Destination>";
    in.destination = getVertex(buf, start, end);

    //read roads
    in.roads = getRoads(buf);

    //read predictions
    in.predictions = getPredictions(buf);
    assert(in.predictions.size() == numOfDays); //if assertion happens it means that the input is not in the right form.
    for(int i = 0; i < in.predictions.size(); i++) { 
        assert(in.predictions[i].road.size() == in.roads.size()); //if assertion happens it means that the input is not in the right form.
    }

    //read actual traffic
    in.actualTraffic = getActualTrafficPerDay(buf);
    assert(in.actualTraffic.size() == numOfDays); //if assertion happens it means that the input is not in the right form.
    for(int i = 0; i < in.actualTraffic.size(); i++) {
        assert(in.actualTraffic[i].road.size() == in.roads.size()); //if assertion happens it means that the input is not in the right form.
    }
    
    return in;
}