#include "functions.h"

using namespace std;

int main() {
    clock_t programClock = clock();
    string outputFile = "output.txt";
    string fileName = "sampleGraph1.txt";
    string output = "";
    ifstream t(fileName);
    ofstream out;
    stringstream buffer;
    buffer << t.rdbuf();
    string stringInput = buffer.str();
    t.close();

    input in = readInput(stringInput);
    srand(time(NULL)); // making the fuction rand() stop producing the same sequence of pseudo-random numbers by taking the time as a "seed".

    clock_t discardClock = clock();
    unordered_set<string> discardedRoads = discardUnnecessaryRoads(in.roads);
    double discardTime = 1000*(double)(clock() - discardClock)/CLOCKS_PER_SEC;

    unordered_map<string, int> roadToIndex = createRoadToIndex(in.roads);
    unordered_map<string, int> nodeToIndex = createNodeToInt(in.roads);
    unordered_map<int, string> indexToNode = createIntToNode(nodeToIndex);
    int sizeOfGraph = indexToNode.size();

    if( (!roadInGraph(nodeToIndex, in.source)) || (!roadInGraph(nodeToIndex, in.destination)) ) {
        cout << "Invalid source and/or destination!\n";
        return -1;
    }

    graphType graph(sizeOfGraph);
    createGraph(graph, in.roads, nodeToIndex);

    ucsResult ucsPredRes = {INT_MIN, INT_MIN, INT_MIN, {}}, ucsActRes = {INT_MIN, INT_MIN, INT_MIN, {}};
    idaStarResult idaStarPredRes = {INT_MIN, INT_MIN, INT_MIN, {}}, idaStarActRes = {INT_MIN, INT_MIN, INT_MIN, {}};
    lrtaStarResult lrtaStarActRes = {__DBL_MIN__, __DBL_MIN__, {}};
    vector<Road> predictedTraffic, actualTraffic;
    vector<double> predictedCost(numOfDays), actualCost(numOfDays), lrtaStarCost(numOfDays), heuristic(numOfDays), heurCreationTime(numOfDays, 0);
    double ucsTime = 0, idaStarTime = 0, heurTime = 0, lrtaStarTime = 0, p1 = 0.6, p2 = 0.2, p3 = 0.2;
    int p1_counter = 0, p2_counter = 0, p3_counter = 0, lrtaStarNo = 100, ltraStarNoToMakeHeuristic = 50;
    for(int i = 0; i < numOfDays; i++) {
        /*
         * Read predictions & actual traffic & create 1 graph for each of them.
         */
        graphType predictedGraph(sizeOfGraph), actualGraph(sizeOfGraph);
        Day d1 = in.predictions[i];
        Day d2 = in.actualTraffic[i];
        copyRoads(in.roads, predictedTraffic);
        copyRoads(in.roads, actualTraffic);
        updateRoads(true, p1, p2, p3, d1, predictedTraffic, discardedRoads, roadToIndex);
        updateRoads(false, p1, p2, p3, d2, actualTraffic, discardedRoads, roadToIndex);
        createGraph(predictedGraph, predictedTraffic, nodeToIndex);
        createGraph(actualGraph, actualTraffic, nodeToIndex);
        predictedTraffic.clear();
        actualTraffic.clear();

        /*
         * Solve the problem with chosen algorithms for both the predicted and the actual traffic.
         */
        //UCS
        ucsPredRes = UCS(predictedGraph, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);
        ucsTime += ucsPredRes.runtime;
        ucsActRes = UCS(actualGraph, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);

        //IDA* with heuristic on predicted traffic
        heuristic = createSimpleHeuristic(graph, sizeOfGraph, nodeToIndex[in.destination]); //create heuristic according to the initial graph in terms of traffic.
        for(int j = 0; j < ltraStarNoToMakeHeuristic; j++) {
            lrtaStarActRes = lrtaStar(predictedGraph, heuristic, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);
            heurTime += lrtaStarActRes.runtime;
            heurCreationTime[i] += lrtaStarActRes.runtime;
        }
        idaStarPredRes = idaStar(predictedGraph, heuristic, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);
        idaStarTime += idaStarPredRes.runtime;

        //IDA* & LRTA* on actual traffic
        heuristic = createSimpleHeuristic(graph, sizeOfGraph, nodeToIndex[in.destination]);
        for(int j = 0; j < lrtaStarNo; j++) {
            lrtaStarActRes = lrtaStar(actualGraph, heuristic, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);
            lrtaStarTime += lrtaStarActRes.runtime;
        }
        idaStarActRes = idaStar(actualGraph, heuristic, sizeOfGraph, nodeToIndex[in.source], nodeToIndex[in.destination]);

        /*
         * Change p1, p2, p3 according to what happened and our definition of them.
         */
        predictedCost[i] = ucsPredRes.cost; //ucs and ida* both produce the same cost since they're both optimal.
        actualCost[i] = ucsActRes.cost;
        lrtaStarCost[i] = lrtaStarActRes.cost;
        for(int j = 0; j < d1.road.size(); j++) {
            assert(d1.road[j].first == d2.road[j].first); //if this assertion fails then you should input the roads in <ActualTrafficPerDay>...</ActualTrafficPerDay> at the same order they are inputed in <Predictions>...</Predictions>.
            trafficWeight pred = d1.road[j].second;
            trafficWeight act = d2.road[j].second;
            if(pred == act) 
                p1_counter++;
            else if((pred == low && act == normal) || (pred == normal && act == heavy) || (pred == heavy && act == normal))
                p2_counter++;
            else
                p3_counter++;
        }
        double s = p1_counter + p2_counter + p3_counter;
        p1 = p1_counter/s;
        p2 = p2_counter/s;
        p3 = p3_counter/s;

        /*
         * Save the results of the algorithm for this particular day.
         */
        idaStarPredRes.runtime += heurCreationTime[i];
        output += getDailyStats(predictedGraph, i+1, ucsPredRes, ucsActRes, idaStarPredRes, idaStarActRes, in.destination, nodeToIndex, indexToNode);
    }

    // Write the results in the output file.
    out.open(outputFile);
    out << output;
    out.close();

    // Print the output along with some extra stats.
    double programRuntime = 1000*(double)(clock() - programClock)/CLOCKS_PER_SEC; // we don't include printing on the console in the running time of the program.
    cout << output << "\n";
    printExtraStatistics(predictedCost, actualCost, lrtaStarCost, discardTime, ucsTime, idaStarTime, idaStarTime + heurTime, lrtaStarTime, p1, p2, p3, lrtaStarNo, programRuntime);

    return 0;
}