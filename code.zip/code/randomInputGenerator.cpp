#include <bits/stdc++.h> //all libraries

using namespace std;

int main() {
    srand(time(NULL));

    string outputFile = "randomGraph.txt"; //output file
    ofstream out;
    string output;

    vector<string> roads;
    int roadSize=1500; //#roads
    vector<string> nodes;
    int nodeSize=ceil(roadSize/3); //#cities
    int minRoadWeight=1;
    int maxRoadWeight=100;

    //initialize road names
    for(int i=0; i<roadSize; i++) {
        string s = "Road"+to_string(i)+"e";
        roads.push_back(s);
    }
    //initialize node/city names
    for(int i=0; i<nodeSize; i++) {
        string s = "Node"+to_string(i)+"e";
        nodes.push_back(s);
    }
    
    //for <Source> and <Destination>
    output = "<Source>" + nodes[(rand() % nodeSize)]+ "</Source>" + "\n"+ "<Destination>"+ nodes[(rand() % nodeSize)] +
    "</Destination>"+"\n";

    //for <Roads>
    output+="<Roads>\n";
    string s="";
    string n1="1";
    string n2="1";
    for(int i=0; i<roadSize; i++) {
        while(n1 == n2) {
            n1 = nodes[rand() % nodeSize];
            n2 = nodes[rand() % nodeSize];
        }
        output+=roads.at(i)+"; " +n1+"; " +n2+"; "+ to_string(rand()%(maxRoadWeight-minRoadWeight + 1) + minRoadWeight)+"\n";
        n1=n2;
    }output+="</Roads>\n";

    //for <ActualTrafficPerDay>
    double p_low=1/3; //these 3 probabilities do not matter in the result of p1,p2,p3
    double p_normal=1/3;
    double p_high=1/3;
    string actual="";
    string traffic;
    vector<vector<string>> v;
    actual+="<ActualTrafficPerDay>\n";
    for(int count=0; count<80; count++) {
        actual+="<Day>\n";
        vector<string> temp;
        for(int i=0; i<roadSize; i++) {
            double p_road = (double)(rand() % 100) /100;
            if(p_road<p_low)
                traffic = "low";
            else if(p_road<p_low+p_normal)
                traffic = "normal";
            else
                traffic = "high";
            temp.push_back(traffic);
            actual+=roads.at(i)+"; " +traffic+"\n";
        }
        v.push_back(temp);
        actual+="</Day>\n";
    }
    actual+="</ActualTrafficPerDay>\n";

    //for <Predictions>
    string prediction="";
    prediction+="<Predictions>\n";
    double p1= 0.2; double p2= 0.1; double p3 = 0.7;
    for(int count=0; count<80; count++) {
        prediction+="<Day>\n";
        for(int i=0; i<roadSize; i++) {
            double p_road = (double)(rand() % 100) /100;
            string k = v[count][i];
            if(k=="low") {
                if(p_road<p1)
                    traffic="low";
                else if(p_road<p1+p2)
                    traffic="normal";
                else
                    traffic="heavy";
            }
            else if(k=="normal") {
                if(p_road<p1)
                    traffic="normal";
                else if(p_road<p1+p2)
                    traffic="heavy";
                else
                    traffic="low";
            }
            else {
                if(p_road<p1)
                    traffic="heavy";
                else if(p_road<p1+p2)
                    traffic="normal";
                else
                    traffic="low";
            }

            prediction+=roads.at(i)+"; " +traffic+"\n";
        }
        prediction+="</Day>\n";
    }
    prediction+="</Predictions>\n";

    output+=prediction;
    output+=actual;    

    //write output in file "sampleGraphGenerator.txt"
    out.open(outputFile);
    out << output;
    out.close();
}